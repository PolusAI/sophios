#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Assemble the final response briefing
doc: Always emit the operational decision, with optional review evidence.

baseCommand: assemble-response-briefing

requirements:
  DockerRequirement:
    dockerPull: vjaganat90/sophios-module06-assemble-response-briefing:1.0.0

inputs:
  summary:
    type: File
    inputBinding:
      prefix: --summary
      position: 1
  notice:
    type: File?
    inputBinding:
      prefix: --notice
      position: 2
  output:
    type: string
    inputBinding:
      prefix: --output
      position: 3

outputs:
  briefing:
    type: File
    outputBinding:
      glob: $(inputs.output)
