#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Write a review follow-up notice
doc: Describe the review finding and the operational correction required.

baseCommand: write-followup-notice

requirements:
  DockerRequirement:
    dockerPull: vjaganat90/sophios-module06-write-followup-notice:1.0.0

inputs:
  summary:
    type: File
    inputBinding:
      prefix: --summary
      position: 1
  status:
    type: string
    inputBinding:
      prefix: --status
      position: 2
  output:
    type: string
    inputBinding:
      prefix: --output
      position: 3

outputs:
  notice:
    type: File?
    outputBinding:
      glob: $(inputs.output)
