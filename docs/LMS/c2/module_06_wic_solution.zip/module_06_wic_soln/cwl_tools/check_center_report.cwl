#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Check one cooling center report
doc: Validate one center report and write a deterministic JSON summary.

baseCommand: check-center-report

requirements:
  DockerRequirement:
    dockerPull: vjaganat90/sophios-module06-check-center-report:1.0.0

inputs:
  report:
    type: File
    inputBinding:
      prefix: --report
      position: 1
  center:
    type: string
    inputBinding:
      prefix: --center
      position: 2
  output:
    type: string
    inputBinding:
      prefix: --output
      position: 3

outputs:
  summary:
    type: File
    outputBinding:
      glob: $(inputs.output)
