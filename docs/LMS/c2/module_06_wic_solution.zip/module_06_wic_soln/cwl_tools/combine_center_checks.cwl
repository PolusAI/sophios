#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Combine cooling center checks
doc: Apply the all-centers-pass policy and emit a citywide summary and scalar status.

baseCommand: combine-center-checks

requirements:
  DockerRequirement:
    dockerPull: vjaganat90/sophios-module06-combine-center-checks:1.0.0
  InlineJavascriptRequirement: {}

inputs:
  summaries:
    type:
      type: array
      items: File
    inputBinding:
      prefix: --summaries
      position: 1
  output:
    type: string
    inputBinding:
      prefix: --output
      position: 2

outputs:
  combined_summary:
    type: File
    outputBinding:
      glob: $(inputs.output)
  status:
    type: string
    outputBinding:
      glob: overall_status.txt
      loadContents: true
      outputEval: $(self[0].contents.trim())
