#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Summarize a basketball game
doc: Calculate the final score, winner, and leading scorer from one player box score.

baseCommand: python
arguments:
  - summarize_game.py

requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
  InitialWorkDirRequirement:
    listing:
      - entryname: summarize_game.py
        entry: |-
          import csv
          import sys

          box_score_csv, game_label, output_tsv = sys.argv[1:]

          with open(box_score_csv, encoding="utf-8", newline="") as stream:
              rows = list(csv.DictReader(stream))

          teams = list(dict.fromkeys(row["team"] for row in rows))
          if len(teams) != 2:
              raise ValueError("A game box score must contain exactly two teams")

          totals = {
              team: sum(int(row["points"]) for row in rows if row["team"] == team)
              for team in teams
          }
          winner = max(teams, key=totals.get)
          leader = max(rows, key=lambda row: int(row["points"]))

          with open(output_tsv, "w", encoding="utf-8", newline="") as stream:
              writer = csv.writer(stream, delimiter="\t")
              writer.writerow([
                  "game", "matchup", "final_score", "winner",
                  "leading_scorer", "leading_scorer_points",
              ])
              writer.writerow([
                  game_label,
                  f"{teams[0]} vs {teams[1]}",
                  f"{totals[teams[0]]}-{totals[teams[1]]}",
                  winner,
                  leader["player"],
                  leader["points"],
              ])

inputs:
  box_score_csv:
    type: File
    format: edam:format_3752
    inputBinding:
      position: 1
  game_label:
    type: string
    inputBinding:
      position: 2
  output_tsv:
    type: string
    inputBinding:
      position: 3

outputs:
  game_summary_tsv:
    type: File
    format: edam:format_3475
    outputBinding:
      glob: $(inputs.output_tsv)

$namespaces:
  edam: https://edamontology.org/
