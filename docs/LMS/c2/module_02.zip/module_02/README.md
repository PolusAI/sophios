# Module 02 — Basketball scatter workflow

This package contains the basketball scatter notebook, its CWL adapter, three fictional box-score files, and the embedded diagrams required by the lab.

## Run

1. Activate the environment created from the Sophios Installation Guide.
2. Change into this extracted `module_02` directory.
3. Start `jupyter lab`.
4. Open `02_scatter_basketball_game_stats.ipynb` and run all cells in order.

The notebook performs a complete Toil-and-Docker execution of three scattered jobs. It verifies that exactly three summaries are produced and checks every winner and leading scorer.

The notebook uses the environment from which JupyterLab was started and reports a specific message if a packaged asset is missing.
