# Module 04 — From failure to evidence

This package contains the troubleshooting notebook and both CWL adapters needed to reproduce an intentional sample-manifest failure and its repair.

## Run

1. Activate the environment created from the Sophios Installation Guide.
2. Change into this extracted `module_04` directory.
3. Start `jupyter lab`.
4. Open `04_inspect_and_troubleshoot_sample_qc.ipynb` and run all cells in order.

The first runner failure is intentional and is asserted by the notebook. The fixed workflow must then succeed and produce `qc_report.txt`.

Each notebook run creates the next available `run_artifacts/session_NNN/` directory. Earlier failed-run evidence is never deleted or overwritten automatically.

The notebook uses the environment from which JupyterLab was started. Its direct use of `cwltool` is intentional for capturing troubleshooting evidence; `cwltool` was installed with Sophios during Course 1.
