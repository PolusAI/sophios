cwlVersion: v1.2
class: CommandLineTool

label: Write the sample manifest
doc: Training adapter that writes the workflow's inline CSV value to samples.csv.

baseCommand: [python, -c]
requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
arguments:
  - position: 1
    valueFrom: |
      from pathlib import Path
      import sys
      Path("samples.csv").write_text(sys.argv[1], encoding="utf-8")

inputs:
  manifest_text:
    type: string
    inputBinding:
      position: 2

outputs:
  manifest:
    type: File
    outputBinding:
      glob: samples.csv
