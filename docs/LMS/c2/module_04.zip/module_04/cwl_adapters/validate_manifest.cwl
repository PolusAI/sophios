cwlVersion: v1.2
class: CommandLineTool

label: Validate the sample manifest
doc: Training adapter that checks required columns, sample IDs, and the expected row count.

baseCommand: [python, -c]
requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
arguments:
  - position: 1
    valueFrom: |
      import csv
      import sys
      from pathlib import Path

      manifest_path = Path(sys.argv[1])
      expected_samples = int(sys.argv[2])
      with manifest_path.open(newline="", encoding="utf-8") as stream:
          reader = csv.DictReader(stream)
          rows = list(reader)
          columns = set(reader.fieldnames or [])

      required_columns = {"sample_id", "condition"}
      missing = sorted(required_columns - columns)
      sample_ids = [row.get("sample_id", "") for row in rows]

      if missing:
          print(f"QC ERROR: missing columns: {', '.join(missing)}", file=sys.stderr)
          raise SystemExit(2)
      if any(not sample_id for sample_id in sample_ids):
          print("QC ERROR: every row needs a sample_id", file=sys.stderr)
          raise SystemExit(2)
      if len(sample_ids) != len(set(sample_ids)):
          print("QC ERROR: sample_id values must be unique", file=sys.stderr)
          raise SystemExit(2)
      if len(rows) != expected_samples:
          print(
              f"QC ERROR: expected {expected_samples} samples, found {len(rows)}",
              file=sys.stderr,
          )
          raise SystemExit(2)

      conditions = sorted({row["condition"] for row in rows})
      Path("qc_report.txt").write_text(
          f"QC passed\nsamples: {len(rows)}\nconditions: {', '.join(conditions)}\n",
          encoding="utf-8",
      )

inputs:
  manifest:
    type: File
    inputBinding:
      position: 2
  expected_samples:
    type: int
    inputBinding:
      position: 3

outputs:
  report:
    type: File
    outputBinding:
      glob: qc_report.txt
