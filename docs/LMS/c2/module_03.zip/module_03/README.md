# Module 03 — Edge inference in support triage

This package contains the edge-inference notebook, three CWL adapters, the fictional support-ticket feed, and the embedded workflow graphs required by the lab.

## Run

1. Activate the environment created from the Sophios Installation Guide.
2. Change into this extracted `module_03` directory.
3. Start `jupyter lab`.
4. Open `03_edge_inference_support_triage.ipynb` and run all cells in order.

The notebook compiles and executes both the explicit-edge and inferred-edge workflows with Toil and Docker. It verifies identical dependencies, identical reports, and the complete expected ticket order.

The notebook uses the environment from which JupyterLab was started and reports a specific message if a packaged asset is missing.
