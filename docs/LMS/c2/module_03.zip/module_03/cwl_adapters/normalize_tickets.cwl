#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Normalize incoming support tickets
doc: Validate the incoming ticket feed and write a consistently formatted TSV table.

baseCommand: python
arguments:
  - normalize_tickets.py

requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
  InitialWorkDirRequirement:
    listing:
      - entryname: normalize_tickets.py
        entry: |-
          import csv
          import datetime
          import sys

          input_csv, output_tsv = sys.argv[1:]
          valid_tiers = {"standard", "premium", "enterprise"}
          valid_categories = {"outage", "security", "billing", "account", "how_to"}

          with open(input_csv, encoding="utf-8", newline="") as stream:
              rows = list(csv.DictReader(stream))

          normalized = []
          for row in rows:
              submitted_at = datetime.datetime.fromisoformat(
                  row["submitted_at"].replace("Z", "+00:00")
              )
              tier = row["customer_tier"].strip().lower()
              category = row["category"].strip().lower()
              waiting_hours = int(row["waiting_hours"])
              if tier not in valid_tiers:
                  raise ValueError(f"Unknown customer tier: {tier}")
              if category not in valid_categories:
                  raise ValueError(f"Unknown ticket category: {category}")
              if waiting_hours < 0:
                  raise ValueError("Waiting time cannot be negative")
              normalized.append({
                  "ticket_id": row["ticket_id"].strip(),
                  "submitted_at": submitted_at.isoformat().replace("+00:00", "Z"),
                  "customer_tier": tier,
                  "category": category,
                  "subject": row["subject"].strip(),
                  "waiting_hours": waiting_hours,
              })

          normalized.sort(key=lambda row: row["submitted_at"])
          fields = [
              "ticket_id", "submitted_at", "customer_tier",
              "category", "subject", "waiting_hours",
          ]
          with open(output_tsv, "w", encoding="utf-8", newline="") as stream:
              writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t")
              writer.writeheader()
              writer.writerows(normalized)

inputs:
  raw_tickets_csv:
    type: File
    format: edam:format_3752
    inputBinding:
      position: 1
  output_tsv:
    type: string
    inputBinding:
      position: 2

outputs:
  normalized_tickets_tsv:
    type: File
    format: edam:format_3475
    outputBinding:
      glob: $(inputs.output_tsv)

$namespaces:
  edam: https://edamontology.org/
