#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Prioritize support tickets
doc: Score tickets by issue category, customer tier, and waiting time, then order the agent queue.

baseCommand: python
arguments:
  - prioritize_tickets.py

requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
  InitialWorkDirRequirement:
    listing:
      - entryname: prioritize_tickets.py
        entry: |-
          import csv
          import sys

          tickets_tsv, output_tsv = sys.argv[1:]
          category_score = {
              "outage": 50,
              "security": 45,
              "billing": 25,
              "account": 20,
              "how_to": 10,
          }
          tier_score = {"enterprise": 20, "premium": 10, "standard": 0}

          with open(tickets_tsv, encoding="utf-8", newline="") as stream:
              tickets = list(csv.DictReader(stream, delimiter="\t"))

          prioritized = []
          for ticket in tickets:
              score = (
                  category_score[ticket["category"]]
                  + tier_score[ticket["customer_tier"]]
                  + min(int(ticket["waiting_hours"]), 24)
              )
              if score >= 65:
                  priority = "urgent"
              elif score >= 40:
                  priority = "high"
              elif score >= 20:
                  priority = "normal"
              else:
                  priority = "low"
              prioritized.append({**ticket, "priority_score": score, "priority": priority})

          prioritized.sort(
              key=lambda row: (-row["priority_score"], row["submitted_at"], row["ticket_id"])
          )
          fields = [
              "queue_position", "ticket_id", "submitted_at", "priority", "priority_score",
              "customer_tier", "category", "waiting_hours", "subject",
          ]
          with open(output_tsv, "w", encoding="utf-8", newline="") as stream:
              writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t")
              writer.writeheader()
              for position, ticket in enumerate(prioritized, start=1):
                  writer.writerow({"queue_position": position, **ticket})

inputs:
  tickets_tsv:
    type: File
    format: edam:format_3475
    inputBinding:
      position: 1
  output_tsv:
    type: string
    inputBinding:
      position: 2

outputs:
  prioritized_tickets_tsv:
    type: File
    format: edam:format_3475
    outputBinding:
      glob: $(inputs.output_tsv)

$namespaces:
  edam: https://edamontology.org/
