#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Publish the agent queue
doc: Format prioritized tickets as a concise work queue for the support team.

baseCommand: python
arguments:
  - publish_agent_queue.py

requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
  InitialWorkDirRequirement:
    listing:
      - entryname: publish_agent_queue.py
        entry: |-
          import csv
          import sys

          prioritized_tickets_tsv, output_txt = sys.argv[1:]
          with open(prioritized_tickets_tsv, encoding="utf-8", newline="") as stream:
              tickets = list(csv.DictReader(stream, delimiter="\t"))

          urgent_count = sum(ticket["priority"] == "urgent" for ticket in tickets)
          lines = [
              "CUSTOMER SUPPORT QUEUE",
              f"Open tickets: {len(tickets)} | Urgent: {urgent_count}",
              "",
              "POS  PRIORITY  TICKET  CUSTOMER    WAIT  SUBJECT",
          ]
          for ticket in tickets:
              lines.append(
                  f"{int(ticket['queue_position']):>3}  "
                  f"{ticket['priority'].upper():<8}  "
                  f"{ticket['ticket_id']:<6}  "
                  f"{ticket['customer_tier']:<10}  "
                  f"{int(ticket['waiting_hours']):>2}h  "
                  f"{ticket['subject']}"
              )

          with open(output_txt, "w", encoding="utf-8") as stream:
              stream.write("\n".join(lines) + "\n")

inputs:
  prioritized_tickets_tsv:
    type: File
    format: edam:format_3475
    inputBinding:
      position: 1
  output_txt:
    type: string
    inputBinding:
      position: 2

outputs:
  agent_queue_txt:
    type: File
    outputBinding:
      glob: $(inputs.output_txt)

$namespaces:
  edam: https://edamontology.org/
