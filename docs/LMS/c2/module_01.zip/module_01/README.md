# Module 01 — Conditional air-quality workflow

This package contains the notebook, three CWL adapters, the sample readings, and the embedded workflow graph required by the lab.

## Run

1. Activate the environment created from the Sophios Installation Guide.
2. Change into this extracted `module_01` directory.
3. Start `jupyter lab`.
4. Open `01_conditional_air_quality.ipynb` and run all cells in order.

The notebook performs two complete Toil-and-Docker executions. The expected reports are written under `output/alert/` and `output/no_alert/`.

The notebook uses the environment from which JupyterLab was started and reports a specific message if a packaged asset is missing.
