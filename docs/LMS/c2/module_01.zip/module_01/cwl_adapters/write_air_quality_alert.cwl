#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Write an air-quality alert
doc: Create an alert artifact from a summary whose status triggered the conditional step.

baseCommand: python
arguments:
  - write_air_quality_alert.py

requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
  InitialWorkDirRequirement:
    listing:
      - entryname: write_air_quality_alert.py
        entry: |-
          import csv
          import sys

          summary_tsv, status, output_txt = sys.argv[1:]
          with open(summary_tsv, encoding="utf-8", newline="") as stream:
              summary = next(csv.DictReader(stream, delimiter="\t"))

          message = (
              "AIR QUALITY ALERT\n"
              f"Station: {summary['station_id']}\n"
              f"Peak PM2.5: {summary['peak_pm25_ug_m3']} ug/m3\n"
              f"Project threshold: {summary['threshold_pm25_ug_m3']} ug/m3\n"
              f"Status: {status}\n"
          )
          with open(output_txt, "w", encoding="utf-8") as stream:
              stream.write(message)

inputs:
  summary_tsv:
    type: File
    format: edam:format_3475
    inputBinding:
      position: 1
  status:
    type: string
    inputBinding:
      position: 2
  output_txt:
    type: string
    default: air_quality_alert.txt
    inputBinding:
      position: 3

outputs:
  alert_txt:
    type: File
    outputBinding:
      glob: $(inputs.output_txt)

$namespaces:
  edam: https://edamontology.org/
