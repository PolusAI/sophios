#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Assemble the station report
doc: Produce the final report whether or not the optional alert step ran.

baseCommand: python
arguments:
  - assemble_air_quality_report.py

requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
  InitialWorkDirRequirement:
    listing:
      - entryname: assemble_air_quality_report.py
        entry: |-
          import argparse
          from pathlib import Path

          parser = argparse.ArgumentParser()
          parser.add_argument("--summary", required=True)
          parser.add_argument("--alert")
          parser.add_argument("--output", required=True)
          args = parser.parse_args()

          summary = Path(args.summary).read_text(encoding="utf-8").strip()
          sections = ["STATION REPORT", "", "ROUTINE SUMMARY", summary]
          if args.alert:
              alert = Path(args.alert).read_text(encoding="utf-8").strip()
              sections.extend(["", "CONDITIONAL RESPONSE", alert])
          else:
              sections.extend(["", "CONDITIONAL RESPONSE", "No alert was generated."])

          Path(args.output).write_text("\n".join(sections) + "\n", encoding="utf-8")

inputs:
  summary_tsv:
    type: File
    format: edam:format_3475
    inputBinding:
      prefix: --summary
      position: 1
  alert_txt:
    type: File?
    inputBinding:
      prefix: --alert
      position: 2
  output_txt:
    type: string
    default: station_report.txt
    inputBinding:
      prefix: --output
      position: 3

outputs:
  report_txt:
    type: File
    outputBinding:
      glob: $(inputs.output_txt)

$namespaces:
  edam: https://edamontology.org/
