#!/usr/bin/env cwl-runner
cwlVersion: v1.2
class: CommandLineTool

label: Classify particulate-matter readings
doc: Summarize a sensor file and classify whether its peak exceeds a project threshold.

baseCommand: python
arguments:
  - classify_air_quality.py

requirements:
  DockerRequirement:
    dockerPull: python:3.11-slim
  InlineJavascriptRequirement: {}
  InitialWorkDirRequirement:
    listing:
      - entryname: classify_air_quality.py
        entry: |-
          import csv
          import sys

          input_csv, threshold_text, output_tsv = sys.argv[1:]
          threshold = float(threshold_text)

          with open(input_csv, encoding="utf-8", newline="") as stream:
              rows = list(csv.DictReader(stream))

          values = [float(row["pm25_ug_m3"]) for row in rows]
          peak = max(values)
          mean = sum(values) / len(values)
          status = "alert" if peak >= threshold else "normal"

          with open(output_tsv, "w", encoding="utf-8", newline="") as stream:
              writer = csv.writer(stream, delimiter="\t")
              writer.writerow(["station_id", "observations", "mean_pm25_ug_m3", "peak_pm25_ug_m3", "threshold_pm25_ug_m3", "status"])
              writer.writerow([rows[0]["station_id"], len(rows), f"{mean:.2f}", f"{peak:.2f}", f"{threshold:.2f}", status])

          with open("status.txt", "w", encoding="utf-8") as stream:
              stream.write(status)

inputs:
  readings_csv:
    type: File
    inputBinding:
      position: 1
  threshold:
    type: float
    inputBinding:
      position: 2
  output_tsv:
    type: string
    default: air_quality_summary.tsv
    inputBinding:
      position: 3

outputs:
  summary_tsv:
    type: File
    format: edam:format_3475
    outputBinding:
      glob: $(inputs.output_tsv)
  status:
    type: string
    outputBinding:
      glob: status.txt
      loadContents: true
      outputEval: $(self[0].contents.trim())

$namespaces:
  edam: https://edamontology.org/
