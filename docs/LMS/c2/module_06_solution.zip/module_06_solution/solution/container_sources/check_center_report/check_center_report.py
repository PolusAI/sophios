#!/usr/bin/env python3
import argparse
import csv
import json
from collections import Counter
from pathlib import Path


REQUIRED_COLUMNS = ("report_id", "time_block", "visitors_served")


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", required=True)
    parser.add_argument("--center", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def main():
    args = parse_arguments()
    report_path = Path(args.report)
    with report_path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        fieldnames = reader.fieldnames or []
        rows = list(reader)

    issues = [
        {"code": "MISSING_COLUMN", "column": column}
        for column in REQUIRED_COLUMNS
        if column not in fieldnames
    ]

    parsed_visitors = []
    for row_number, row in enumerate(rows, start=2):
        for column in REQUIRED_COLUMNS:
            if column in fieldnames and not (row.get(column) or "").strip():
                issues.append(
                    {
                        "code": "EMPTY_VALUE",
                        "row": row_number,
                        "column": column,
                    }
                )

        raw_visitors = (row.get("visitors_served") or "").strip()
        if not raw_visitors:
            continue
        try:
            visitors = int(raw_visitors)
        except ValueError:
            issues.append(
                {
                    "code": "NON_INTEGER_VISITOR_COUNT",
                    "row": row_number,
                    "value": raw_visitors,
                }
            )
            continue
        parsed_visitors.append(visitors)
        if visitors < 0:
            issues.append(
                {
                    "code": "NEGATIVE_VISITOR_COUNT",
                    "row": row_number,
                    "value": visitors,
                }
            )

    report_ids = [(row.get("report_id") or "").strip() for row in rows]
    counts = Counter(report_id for report_id in report_ids if report_id)
    duplicate_ids = sorted(
        report_id for report_id, occurrences in counts.items() if occurrences > 1
    )
    for report_id in duplicate_ids:
        duplicate_rows = [
            row
            for row in rows
            if (row.get("report_id") or "").strip() == report_id
        ]
        duplicate_values = []
        for row in duplicate_rows:
            try:
                duplicate_values.append(
                    int((row.get("visitors_served") or "").strip())
                )
            except ValueError:
                duplicate_values = []
                break
        issue = {
            "code": "DUPLICATE_REPORT_ID",
            "report_id": report_id,
            "occurrences": counts[report_id],
        }
        if duplicate_values and all(value >= 0 for value in duplicate_values):
            issue["overstatement_if_counted"] = sum(duplicate_values[1:])
        issues.append(issue)

    result = {
        "center": args.center,
        "source_basename": report_path.name,
        "rows_checked": len(rows),
        "submitted_visitors": sum(parsed_visitors),
        "status": "PASS" if not issues else "REVIEW",
        "issues": issues,
    }
    Path(args.output).write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
