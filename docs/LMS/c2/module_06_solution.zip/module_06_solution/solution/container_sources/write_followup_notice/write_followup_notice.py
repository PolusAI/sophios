#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--summary", required=True)
    parser.add_argument("--status", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def main():
    args = parse_arguments()
    if args.status != "REVIEW":
        raise ValueError("A follow-up notice may be written only for REVIEW status.")
    with Path(args.summary).open(encoding="utf-8") as stream:
        combined = json.load(stream)

    findings = []
    for center in combined["centers_requiring_review"]:
        for issue in combined["center_results"][center]["issues"]:
            match issue:
                case {
                    "code": "DUPLICATE_REPORT_ID",
                    "report_id": report_id,
                    "occurrences": occurrences,
                    "overstatement_if_counted": overstatement,
                }:
                    findings.append(
                        f"{center}: {report_id} appears {occurrences} times; "
                        f"counting every submitted row risks counting "
                        f"{overstatement} visitors twice."
                    )
                case {"code": code}:
                    findings.append(f"{center}: {code} requires correction.")

    lines = [
        "FOLLOW-UP REQUIRED — HEATWAVE CENTER REPORTS",
        "Overall status: REVIEW",
        "",
        *findings,
        "",
        "Decision: withhold the citywide visitor total.",
        (
            "Action: obtain corrected reports from "
            f"{', '.join(combined['centers_requiring_review'])}, then rerun "
            "the workflow."
        ),
    ]
    Path(args.output).write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
