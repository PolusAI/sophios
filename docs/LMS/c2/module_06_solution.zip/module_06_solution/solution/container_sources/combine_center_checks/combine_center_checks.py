#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--summaries", nargs="+", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def load_summary(path):
    with Path(path).open(encoding="utf-8") as stream:
        return json.load(stream)


def main():
    args = parse_arguments()
    summaries = [load_summary(path) for path in args.summaries]
    center_results = {summary["center"]: summary for summary in summaries}
    centers_requiring_review = [
        center
        for center, result in center_results.items()
        if result["status"] != "PASS"
    ]
    overall_status = "PASS" if not centers_requiring_review else "REVIEW"
    submitted_total = sum(
        result["submitted_visitors"] for result in center_results.values()
    )
    combined = {
        "overall_status": overall_status,
        "centers_checked": len(center_results),
        "centers_passed": sum(
            result["status"] == "PASS" for result in center_results.values()
        ),
        "centers_requiring_review": centers_requiring_review,
        "submitted_citywide_visitors": submitted_total,
        "cleared_citywide_visitors": (
            submitted_total if overall_status == "PASS" else None
        ),
        "center_results": center_results,
    }
    Path(args.output).write_text(
        json.dumps(combined, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    Path("overall_status.txt").write_text(
        overall_status + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
