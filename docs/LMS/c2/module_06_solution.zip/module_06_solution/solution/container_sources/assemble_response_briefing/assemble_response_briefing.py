#!/usr/bin/env python3
import argparse
import json
from pathlib import Path


def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--summary", required=True)
    parser.add_argument("--notice")
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def main():
    args = parse_arguments()
    with Path(args.summary).open(encoding="utf-8") as stream:
        combined = json.load(stream)

    match combined["overall_status"]:
        case "PASS":
            lines = [
                "HEATWAVE RESPONSE BRIEFING",
                "Decision status: PASS",
                f"Center checks: all {combined['centers_checked']} centers passed.",
                (
                    "Cleared citywide visitor total: "
                    f"{combined['cleared_citywide_visitors']} visitors."
                ),
                "Action: use the cleared total for evening response planning.",
            ]
        case "REVIEW":
            centers = ", ".join(combined["centers_requiring_review"])
            lines = [
                "HEATWAVE RESPONSE BRIEFING",
                "Decision status: REVIEW",
                (
                    f"Center checks: {combined['centers_passed']} of "
                    f"{combined['centers_checked']} passed."
                ),
                "Citywide visitor total: WITHHELD pending report correction.",
                f"Action: contact {centers} and rerun after correction.",
            ]
            if args.notice:
                notice = Path(args.notice).read_text(encoding="utf-8").strip()
                lines.extend(["", "Follow-up record:", notice])
        case unexpected:
            raise ValueError(f"Unsupported overall status: {unexpected!r}")

    Path(args.output).write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
