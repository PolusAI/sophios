# Module 06 Python API reference solution

This folder contains the formal end-to-end Python API solution for the heatwave-response capstone.

Activate the Sophios environment created during Course 1, start JupyterLab from this directory, open `06_heatwave_response_python_solution.ipynb`, and run all cells in order. The notebook builds four image-backed CWL Tool Contracts in memory, composes and compiles the workflow, runs both the review and pass scenarios with `toil-cwl-runner` and Docker, and presents the resulting decisions.

## Packaged inputs

- `data/`: the original and corrected center reports plus their data dictionary.
- `scenarios/`: package-relative input manifests for the review and pass runs.
- `expected/`: implementation-independent acceptance results.
- `container_sources/`: instructor source and Docker build contexts for the four published applications.

No generated contracts, execution directories, or output artifacts are distributed. Running the notebook creates `compiled/`, `execution/`, and `output/` beside it.
