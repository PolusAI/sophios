# Cooling-center report data dictionary

All files are UTF-8 CSV with one header row. The records are fictional and contain no personal information.

| Column | Type | Meaning | Validation rule |
|---|---|---|---|
| `report_id` | string | Identifier for one center reporting record | Required and unique within a report |
| `time_block` | string | Local reporting interval in `HH:MM-HH:MM` form | Required and non-empty |
| `visitors_served` | integer | Aggregate visitors served during the interval | Required, whole, and greater than or equal to zero |

`eastside_center.csv` intentionally repeats the complete `EAS-002` record. Counting it would overstate Eastside activity by 82 visitors. `eastside_center_corrected.csv` removes that duplicate and is the replacement input for the all-pass scenario.

The submitted totals are:

| Report | Rows | Submitted visitors | Expected QC status |
|---|---:|---:|---|
| Riverside | 4 | 292 | `PASS` |
| Eastside, original | 5 | 412 | `REVIEW` |
| Eastside, corrected | 4 | 330 | `PASS` |
| Hilltop | 4 | 240 | `PASS` |

The corrected citywide total is **862 visitors**. The original review-case total must not be presented as operationally cleared.
