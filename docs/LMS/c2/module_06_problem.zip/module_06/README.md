# Module 06 — Heatwave response capstone

Three fictional cooling centers have submitted aggregate visitor reports during a severe heatwave. Your workflow must decide whether the city can safely use the combined total for evening staffing, transportation, and supply planning.

The four executable applications already exist as published container images. You do not write the application code: create one CWL CommandLineTool (CLT) for each image, then compose those four tools into the complete workflow.

Start with `MODULE_06_CAPSTONE_HEATWAVE_RESPONSE.docx`. It contains the learner-facing problem, authoring choices, workflow requirements, and definition of success.

## Package contents

- `data/`: three original center reports, a corrected Eastside report, and the data dictionary.
- `scenarios/`: aligned file, label, and output-name arrays for the review and pass cases.
- `specifications/TOOL_INTERFACE_SPEC.md`: the four published images and their exact command-line interfaces.
- `expected/expected_results.json`: the exact, implementation-independent outcomes used to verify both runs.

The Python and WIC reference solutions are distributed separately in the LMS Solution section. Complete the activity before opening them.

## Authoring boundary

This is a capstone, so the package provides the four executable applications as container images but does not provide finished Tool Contracts or a completed workflow. Your authoring work begins at the executable interface: turn each supplied image and command specification into a CLT, then connect the resulting tools.

For an end-to-end Python solution, construct the four image-backed Tool Contracts, steps, scatter, conditional, and workflow in memory with the Sophios Python API. For a `.wic` solution, write the required CLTs as raw CWL or generate them with the Python API, then compose the workflow in `.wic`.

Use only package-relative paths. Do not encode machine-specific directories in a Tool Contract or workflow.

## Required workflow

The workflow checks three center reports with a dot-product scatter, combines the resulting JSON summaries, writes a follow-up notice only when the combined status is `REVIEW`, and always produces a final response briefing.

Run both scenario manifests. The review case must identify Eastside's duplicated `EAS-002` record and withhold the citywide total. The pass case must skip the notice, still produce the final briefing, and report a cleared total of 862 visitors.

The workflow is complete only when the contracts validate, each logical step uses its specified image and command, compilation exposes the intended scatter and conditional sources, both executions succeed, and the produced evidence matches `expected/expected_results.json`.
