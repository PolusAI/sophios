# Container application interfaces

The four applications are already implemented and published as separate container images. Do not write or replace their application code. Your task is to create one valid CWL CommandLineTool (CLT) for each image from the interfaces below, then compose those four tools into the required workflow.

The images do not define an entrypoint. Set each CLT's `baseCommand` to the command shown below and its `DockerRequirement.dockerPull` to the corresponding image.

## 1. Check one center report

- Image: `vjaganat90/sophios-module06-check-center-report:1.0.0`
- Command: `check-center-report`
- Arguments:
  - `--report` followed by one report `File`
  - `--center` followed by one center-label `string`
  - `--output` followed by one requested summary-filename `string`
- Output: one JSON summary `File` whose basename is the value supplied to `--output`

The JSON contains `center`, `source_basename`, `rows_checked`, `submitted_visitors`, `status`, and `issues`.

## 2. Combine center checks

- Image: `vjaganat90/sophios-module06-combine-center-checks:1.0.0`
- Command: `combine-center-checks`
- Arguments:
  - `--summaries` followed by one or more summary files (`File[]`)
  - `--output` followed by one requested combined-summary filename `string`
- Outputs:
  - one combined JSON `File` whose basename is the value supplied to `--output`
  - one scalar status `string`, read from the generated file `overall_status.txt`

The status file contains `PASS` or `REVIEW` followed by a newline. Define the status output with `glob: overall_status.txt`, `loadContents: true`, and an `outputEval` expression that returns the trimmed contents.

## 3. Write a follow-up notice

- Image: `vjaganat90/sophios-module06-write-followup-notice:1.0.0`
- Command: `write-followup-notice`
- Arguments:
  - `--summary` followed by the combined-summary `File`
  - `--status` followed by the overall-status `string`
  - `--output` followed by one requested notice-filename `string`
- Output: one notice `File` whose basename is the value supplied to `--output`

The workflow must invoke this CLT only when status is `REVIEW`.

## 4. Assemble the final briefing

- Image: `vjaganat90/sophios-module06-assemble-response-briefing:1.0.0`
- Command: `assemble-response-briefing`
- Arguments:
  - `--summary` followed by the combined-summary `File`
  - optional `--notice` followed by the notice `File?`
  - `--output` followed by one requested briefing-filename `string`
- Output: one briefing `File` whose basename is the value supplied to `--output`

The notice input must be optional so this CLT runs whether the conditional notice step executes or is skipped.

## Authoring boundary

Do not reimplement or inspect the applications. Author four CLTs that faithfully describe these image/command interfaces, validate them, and compose the capstone workflow. Use only package-relative paths for workflow data and generated artifacts.
